/*
 * Copyright (c) 2012, Codename One and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Codename One designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *  
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 * 
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 * 
 * Please contact Codename One through http://www.codenameone.com/ if you 
 * need additional information or have any questions.
 */

package com.codename1.ui;

import com.codename1.ui.util.ImageIO;

/**
 * The URLImage allows us to create an image from a URL. If the image was downloaded 
 * already it is fetched from cache; if not it is downloaded optionally scaled/adapted
 * and placed in cache.
 * <p>By default an image is fetched lazily as it is asked for by the GUI unless 
 * the fetch() method is invoked in which case the IO code is executed immediately.
 *
 * @author Shai Almog
 */
class URLImage extends EncodedImage {
    /**
     * Indicates the possible scale behaviors
     */
    /*public enum ScaleBehavior {
        FAIL, SCALE, SCALE_TO_FIT, SCALE_TO_FILL
    };*/
    
    private int letterBoxColor = 0x0;
    
    private String scaleFormat = ImageIO.FORMAT_JPEG;
    
    /**
     * @inheritDoc 
     */
    protected URLImage(int width, int height) {
        super(width, height);
    }

    /**
     * Images are normally fetched from storage or network only as needed, 
     * however if the 
     */
    public void fetch() {
    }
    
    /*public static URLImage create(Image placeholder, String url) {
        
    }*/
}
